class Piece
  def initialize

  end
end