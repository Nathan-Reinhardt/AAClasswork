const MovingObject = require("./moving_object.js");


module.exports = Ship;