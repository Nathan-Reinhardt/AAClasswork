require_relative 'piece.rb'

class King < Piece
  def move_dirs
    
  end

  def symbol
    '♔'
  end
end