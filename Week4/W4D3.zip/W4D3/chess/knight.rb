require_relative 'piece.rb'

class Knight < Piece

  def move_dirs
    
  end

  def symbol
    '♘'
  end
  
end